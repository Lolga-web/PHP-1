-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 22 2020 г., 10:33
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `id_user` int NOT NULL,
  `id_good` int NOT NULL,
  `quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `id_user`, `id_good`, `quantity`) VALUES
(37, 0, 1, 2),
(38, 0, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `img` text NOT NULL,
  `short_description` text NOT NULL,
  `description` text NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `img`, `short_description`, `description`, `price`) VALUES
(1, 'Товар №1', '1.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 2990),
(2, 'Товар №2', '2.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 1990),
(3, 'Товар №3', '3.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 2990),
(4, 'Товар №4', '4.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 3490),
(5, 'Товар №5', '5.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 3990);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `login` varchar(100) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`) VALUES
(1, 'admin', 'admin'),
(2, 'user', 'user');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

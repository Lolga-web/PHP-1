-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 19 2020 г., 04:59
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `img` text NOT NULL,
  `short_description` text NOT NULL,
  `description` text NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `img`, `short_description`, `description`, `price`) VALUES
(1, 'Товар №1', '1.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 2990),
(2, 'Товар №2', '2.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 1990),
(3, 'Товар №3', '3.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 2990),
(4, 'Товар №4', '4.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 3490),
(5, 'Товар №5', '5.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Unde, modi! Ex dolorum placeat ipsum quae necessitatibus, excepturi voluptas voluptates, itaque quaerat odio, dignissimos dolorem iure? Totam velit possimus aperiam, modi temporibus blanditiis quo alias soluta et! At voluptas quibusdam cumque dolore illum labore ad, beatae suscipit impedit animi tempore nihil. Nulla odit possimus odio atque provident veniam esse quam accusamus sunt enim libero dolorum magnam, corporis quo, dolorem quae officia nostrum asperiores. Ullam, nisi! In fugiat adipisci eligendi a minima nulla animi odit quia, ea et quod consequatur provident, accusamus eius facere veritatis voluptatum totam officiis nobis ab commodi tempore!', 3990);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
